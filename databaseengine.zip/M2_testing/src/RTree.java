//
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import gnu.trove.procedure.TIntProcedure;
//
//import net.sf.jsi.SpatialIndex;
//import net.sf.jsi.rtree.RTree;
//import net.sf.jsi.Rectangle;
//import net.sf.jsi.Point;

public class RTree {

	public RTree(String strTableName, String strColName, int nodeSize, String strColType ){
		// set strColType to Region
	}
	
}
