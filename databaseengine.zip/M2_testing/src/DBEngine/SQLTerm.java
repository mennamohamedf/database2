package DBEngine;

public class SQLTerm {
public String strTableName;
public String strColumnName;
String strOperator;
Object objValue;

}
