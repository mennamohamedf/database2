
public class SQLTerm {
String strTableName;
String strColumnName;
String strOperator;
Object objValue;

}
